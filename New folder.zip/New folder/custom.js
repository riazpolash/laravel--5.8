$(document).ready(function(){
	// android menu hover section
	$("#clickmenu").mouseover(function(){
		$(".navigation").slideToggle(500);
		$(".clickmenu").css({"right":"4%","background-color":"#090325"});
	});
	$("#clickmenu").mouseleave(function(){
		$(this).css({"background":""});
	});
	// end android menu hover section
	// skills animation section
$(".msoffice").css({"width":"90%","background":"#090325"});
$(".wdesign").css({"width":"80%","background":"#090325"});
$(".wdev").css({"width":"50%","background":"#090325"});
$(".laravel").css({"width":"60%","background":"#090325"});
$(".adobephotoshop").css({"width":"60%","background":"#090325"});
$(".adobeillustrator").css({"width":"40%","background":"#090325"});
		// end skills animation section


//end
});
